﻿using System;
using System.Reflection;

namespace Xamarin.Forms.Core
{
    public class CoreTelephonyPage : CorePage { }
    public class CoreTelephonyPage<T> : CoreTelephonyPage
        where T : CoreViewModel
    {

    }
}
