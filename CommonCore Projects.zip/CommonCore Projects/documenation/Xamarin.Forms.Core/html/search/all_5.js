var searchData=
[
  ['fabcontrolsize',['FABControlSize',['../namespace_xamarin_1_1_forms_1_1_core_1_1_material_design.html#a0f665feca336b106f06fa6f1c6f3bab5',1,'Xamarin::Forms::Core::MaterialDesign']]],
  ['fadeoutanimation',['FadeOutAnimation',['../class_xamarin_1_1_forms_1_1_core_1_1_fade_out_animation.html',1,'Xamarin.Forms.Core.FadeOutAnimation'],['../class_xamarin_1_1_forms_1_1_common_core_1_1_fade_out_animation.html',1,'Xamarin.Forms.CommonCore.FadeOutAnimation']]],
  ['filestore',['FileStore',['../class_xamarin_1_1_forms_1_1_core_1_1_file_store.html',1,'Xamarin.Forms.Core.FileStore'],['../class_xamarin_1_1_forms_1_1_core_1_1_core_business.html#ae697743338cba4b3b5ff9d054d483688',1,'Xamarin.Forms.Core.CoreBusiness.FileStore()'],['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#ab922da95ae8d825a87b57ebc34c5f041',1,'Xamarin.Forms.Core.CoreViewModel.FileStore()']]]
];
