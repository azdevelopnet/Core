var searchData=
[
  ['sendviewmessage',['SendViewMessage',['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#a77dbe2ccd7c352a03a68d8ada6391942',1,'Xamarin::Forms::Core::CoreViewModel']]],
  ['sendviewmessage_3c_20t_20_3e',['SendViewMessage&lt; T &gt;',['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#abcd0b58fa299ae556bece83aeab506e8',1,'Xamarin::Forms::Core::CoreViewModel']]],
  ['sendviewmodelmessage',['SendViewModelMessage',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#a10246149eed19f94230baead076ef6d5',1,'Xamarin::Forms::Core::CoreDependencyService']]],
  ['sendviewmodelmessage_3c_20t_20_3e',['SendViewModelMessage&lt; T &gt;',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#af7e552f8edaeeca8d47e2d7cf4a1884b',1,'Xamarin::Forms::Core::CoreDependencyService']]]
];
