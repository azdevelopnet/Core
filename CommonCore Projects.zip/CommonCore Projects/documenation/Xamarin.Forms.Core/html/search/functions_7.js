var searchData=
[
  ['refreshasync',['RefreshAsync',['../class_xamarin_1_1_forms_1_1_core_1_1_refreshing_collection.html#a90c5454a88ca3821dd0cf60acbc9c260',1,'Xamarin::Forms::Core::RefreshingCollection']]],
  ['refreshingcollection',['RefreshingCollection',['../class_xamarin_1_1_forms_1_1_core_1_1_refreshing_collection.html#ab84757a8bc40a6c07a4c362ca983927c',1,'Xamarin::Forms::Core::RefreshingCollection']]],
  ['releaseallresources',['ReleaseAllResources',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#a220f6f4cc2435ae28479a5981077fdd3',1,'Xamarin::Forms::Core::CoreDependencyService']]],
  ['releaseresources_3c_20t_20_3e',['ReleaseResources&lt; T &gt;',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#a806d08c9f97b1325df6243cda3cbae89',1,'Xamarin::Forms::Core::CoreDependencyService']]],
  ['reloadallresources',['ReloadAllResources',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#a3acdd0fe17d5a75d4fc3e10b157a11fd',1,'Xamarin::Forms::Core::CoreDependencyService']]]
];
