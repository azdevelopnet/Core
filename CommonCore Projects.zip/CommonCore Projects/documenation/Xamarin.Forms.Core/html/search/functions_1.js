var searchData=
[
  ['convert',['Convert',['../class_xamarin_1_1_forms_1_1_core_1_1_hex_to_color_converter.html#ad0ee9c9ddbc1f3ad8ef808e1d908ced9',1,'Xamarin.Forms.Core.HexToColorConverter.Convert()'],['../class_xamarin_1_1_forms_1_1_core_1_1_inverted_boolean_converter.html#ac0f6a69639d19b517c068521870f9fd4',1,'Xamarin.Forms.Core.InvertedBooleanConverter.Convert()']]],
  ['convertback',['ConvertBack',['../class_xamarin_1_1_forms_1_1_core_1_1_hex_to_color_converter.html#a4a079a920a5e87df6a879a5fadd68fa2',1,'Xamarin.Forms.Core.HexToColorConverter.ConvertBack()'],['../class_xamarin_1_1_forms_1_1_core_1_1_inverted_boolean_converter.html#ac708363eb74f3821e702c99856d8b48d',1,'Xamarin.Forms.Core.InvertedBooleanConverter.ConvertBack()']]]
];
