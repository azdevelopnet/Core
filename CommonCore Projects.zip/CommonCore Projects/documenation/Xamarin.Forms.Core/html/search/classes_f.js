var searchData=
[
  ['telephonycompletestatus',['TelephonyCompleteStatus',['../class_xamarin_1_1_forms_1_1_core_1_1_telephony_complete_status.html',1,'Xamarin::Forms::Core']]],
  ['textarea',['TextArea',['../class_common_1_1_core_1_1_text_area.html',1,'Common::Core']]]
];
