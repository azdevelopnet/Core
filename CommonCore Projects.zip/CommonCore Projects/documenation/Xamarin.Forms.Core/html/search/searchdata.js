var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvx",
  1: "abcdefghilmoprstuv",
  2: "cx",
  3: "bcdgioprsv",
  4: "cdehs",
  5: "f",
  6: "abcdefhiklmnoprsv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Properties"
};

