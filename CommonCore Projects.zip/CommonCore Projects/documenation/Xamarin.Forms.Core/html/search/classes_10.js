var searchData=
[
  ['uppertextconverter',['UpperTextConverter',['../class_xamarin_1_1_forms_1_1_core_1_1_upper_text_converter.html',1,'Xamarin::Forms::Core']]]
];
