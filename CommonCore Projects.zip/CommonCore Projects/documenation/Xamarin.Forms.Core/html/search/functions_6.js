var searchData=
[
  ['play',['Play',['../interface_xamarin_1_1_forms_1_1_core_1_1_i_audio_player.html#adf26d5b52877e8b0d50104b0850d0689',1,'Xamarin::Forms::Core::IAudioPlayer']]]
];
