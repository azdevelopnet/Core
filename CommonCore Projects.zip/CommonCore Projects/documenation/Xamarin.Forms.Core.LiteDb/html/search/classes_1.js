var searchData=
[
  ['ilitenosql',['ILiteNoSql',['../interface_xamarin_1_1_forms_1_1_common_core_1_1_i_lite_no_sql.html',1,'Xamarin::Forms::CommonCore']]]
];
