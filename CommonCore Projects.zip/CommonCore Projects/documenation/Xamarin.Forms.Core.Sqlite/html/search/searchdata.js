var indexSectionsWithContent =
{
  0: "acisx",
  1: "acis",
  2: "x",
  3: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Properties"
};

