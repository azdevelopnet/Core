var searchData=
[
  ['corebusiness',['CoreBusiness',['../class_xamarin_1_1_forms_1_1_core_1_1_core_business.html',1,'Xamarin::Forms::Core']]],
  ['coreconfiguration',['CoreConfiguration',['../class_xamarin_1_1_forms_1_1_core_1_1_core_configuration.html',1,'Xamarin::Forms::Core']]],
  ['coresqlmodel',['CoreSqlModel',['../class_xamarin_1_1_forms_1_1_core_1_1_core_sql_model.html',1,'Xamarin::Forms::Core']]],
  ['coreviewmodel',['CoreViewModel',['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html',1,'Xamarin::Forms::Core']]]
];
