﻿namespace Xamarin.Forms.Core
{
    public enum EasingType
    {
        BounceIn,
        BounceOut,
        CubicIn,
        CubicInOut,
        CubicOut,
        Linear,
        SinIn,
        SinInOut,
        SinOut,
        SpringIn,
        SpringOut
    }
}
