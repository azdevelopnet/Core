﻿using System;
namespace Xamarin.Forms.Core
{
	public class EmailMessage
	{
		public string EmailAddress { get; set; }
		public string Subject { get; set; }
		public string Message { get; set; }
		public string Title { get; set; }
	}
}
