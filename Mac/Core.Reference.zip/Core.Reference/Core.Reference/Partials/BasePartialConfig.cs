﻿using System;

namespace Xamarin.Forms.Core
{
    /// <summary>
    /// This partial allows the application to extended configuration options
    /// </summary>
    public partial class CoreConfiguration
    {

    }

}
