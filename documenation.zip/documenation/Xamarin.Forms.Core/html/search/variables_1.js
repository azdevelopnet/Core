var searchData=
[
  ['disabledtextcolorproperty',['DisabledTextColorProperty',['../class_xamarin_1_1_forms_1_1_core_1_1_core_button.html#a67e6a189f68f7cc8bda2d51f96d4c678',1,'Xamarin::Forms::Core::CoreButton']]]
];
