var searchData=
[
  ['securedataservice',['SecureDataService',['../class_xamarin_1_1_forms_1_1_core_1_1_secure_data_service.html',1,'Xamarin::Forms::Core']]],
  ['snack',['Snack',['../class_xamarin_1_1_forms_1_1_core_1_1_snack.html',1,'Xamarin::Forms::Core']]],
  ['socialmedia',['SocialMedia',['../class_xamarin_1_1_forms_1_1_core_1_1_social_media.html',1,'Xamarin::Forms::Core']]],
  ['stackcontainer',['StackContainer',['../class_xamarin_1_1_forms_1_1_core_1_1_stack_container.html',1,'Xamarin::Forms::Core']]],
  ['starbehavior',['StarBehavior',['../class_xamarin_1_1_forms_1_1_core_1_1_star_behavior.html',1,'Xamarin::Forms::Core']]],
  ['synchronizationcontextremover',['SynchronizationContextRemover',['../struct_xamarin_1_1_forms_1_1_core_1_1_synchronization_context_remover.html',1,'Xamarin::Forms::Core']]]
];
