var searchData=
[
  ['disposeservices',['DisposeServices',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#a3acf52e270e9cfaeaf30603da5a1d921',1,'Xamarin::Forms::Core::CoreDependencyService']]]
];
