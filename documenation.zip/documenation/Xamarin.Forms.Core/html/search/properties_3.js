var searchData=
[
  ['dialogprompt',['DialogPrompt',['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#ac8b5c99b96dd064a9ebb94b080dceed3',1,'Xamarin::Forms::Core::CoreViewModel']]],
  ['duration',['Duration',['../class_xamarin_1_1_forms_1_1_core_1_1_snack.html#ae5edff0a1e78f6591bb1c19dfedd25e6',1,'Xamarin::Forms::Core::Snack']]]
];
