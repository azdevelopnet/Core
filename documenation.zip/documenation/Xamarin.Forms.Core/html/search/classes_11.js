var searchData=
[
  ['valueconversionattribute',['ValueConversionAttribute',['../class_xamarin_1_1_forms_1_1_core_1_1_value_conversion_attribute.html',1,'Xamarin::Forms::Core']]],
  ['viewshadoweffect',['ViewShadowEffect',['../class_xamarin_1_1_forms_1_1_core_1_1_view_shadow_effect.html',1,'Xamarin::Forms::Core']]]
];
