var searchData=
[
  ['refreshingcollection',['RefreshingCollection',['../class_xamarin_1_1_forms_1_1_core_1_1_refreshing_collection.html',1,'Xamarin::Forms::Core']]],
  ['regexbehavior',['RegExBehavior',['../class_xamarin_1_1_forms_1_1_core_1_1_reg_ex_behavior.html',1,'Xamarin::Forms::Core']]],
  ['relativecontainer',['RelativeContainer',['../class_xamarin_1_1_forms_1_1_core_1_1_relative_container.html',1,'Xamarin::Forms::Core']]]
];
