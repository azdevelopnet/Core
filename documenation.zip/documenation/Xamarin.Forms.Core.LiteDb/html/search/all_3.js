var searchData=
[
  ['commoncore',['CommonCore',['../namespace_xamarin_1_1_forms_1_1_common_core.html',1,'Xamarin::Forms']]],
  ['forms',['Forms',['../namespace_xamarin_1_1_forms.html',1,'Xamarin']]],
  ['xamarin',['Xamarin',['../namespace_xamarin.html',1,'']]]
];
