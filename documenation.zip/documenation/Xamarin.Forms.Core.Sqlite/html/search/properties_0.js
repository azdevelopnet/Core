var searchData=
[
  ['sqlitedb',['SqliteDb',['../class_xamarin_1_1_forms_1_1_core_1_1_core_business.html#a8a859d358afddc6e0416dccdc128a51f',1,'Xamarin.Forms.Core.CoreBusiness.SqliteDb()'],['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#a40ea5b867167f44b392250ea41e51272',1,'Xamarin.Forms.Core.CoreViewModel.SqliteDb()']]]
];
