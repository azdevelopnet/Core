﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using Xamarin.Forms.Core;

namespace Pagination
{
    public class SomeViewModel : CoreViewModel
    {
        private int pageIndex = 1;
        private Datum selectedPagingatedDatum;
        private bool _isRefreshing;

        public OptimizedObservableCollection<Datum> PaginatedData { get; set; } = new OptimizedObservableCollection<Datum>();
        public bool IsRefreshing { get => _isRefreshing; set => SetProperty(ref _isRefreshing, value); }

        public ICommand LoadMorePaginatedData { get; set; }
        public ICommand RereshCommand { get; set; }

        public Datum SelectedPagingatedUser
        {
            get { return selectedPagingatedDatum; }
            set
            {
                if (value != null && selectedPagingatedDatum != value)
                {
                    SetProperty(ref selectedPagingatedDatum, value);
                    PageTitle = selectedPagingatedDatum?.name;
                }
            }
        }

        public SomeViewModel()
        {
            LoadMorePaginatedData = new CoreCommand(GetPaginatedData);
            RereshCommand = new CoreCommand(RefeshData);
        }

        public override void OnViewMessageReceived(string key, object obj)
        {
            switch (key)
            {
                case CoreSettings.LoadResources:
                    GetPaginatedData(null);
                    break;
            }
        }

        public void RefeshData(object obj)
        {
            IsRefreshing = true;
            pageIndex = 1;
            PaginatedData.Clear();
            GetPaginatedData(obj);
            IsRefreshing = false;
        }

        public void GetPaginatedData(object obj)
        {
            Task.Run(async () =>
            {
                this.LoadingMessageHUD = "Performing download...";
                this.IsLoadingHUD = true;

                var result = await this.SomeLogic.GetPaginatedData(pageIndex);
                pageIndex++;

                this.IsLoadingHUD = false;
                if (result.Error == null)
                {
                    using (var updated = PaginatedData.BeginMassUpdate())
                    {
                        PaginatedData.AddRange(result.Response);
                    }
                }
                else
                {
                    //Device.BeginInvokeOnMainThread(() => {
                    //    DialogPrompt.ShowMessage(new Prompt()
                    //    {
                    //        Title = "Error",
                    //        Message = result.Error.Message
                    //    });
                    //});
                }

            });

        }

    }
}
